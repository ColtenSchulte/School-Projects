/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dahw1;

import java.util.Random;

/**
 *
 * @author colts
 */
public class DAHW1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int UB = 100;
        int LB = 0;
        Random R = new Random();
        int[][] A = new int [20][10];
        for(int row = 0; row<A.length; ++row){
            for(int col = 0; col<A[row].length; ++col){
                A[row][col] = R.nextInt(UB-LB+1)+LB;
                
            }
            
        }
        double sum = 0;
        double divisor = 0;
        for(int row = 0; row<A.length; ++row){
            for(int col = 0; col<A[row].length; ++col){ 
                ++divisor;
                sum += A[row][col];
                
            }
    }
        double mean = 0;
        mean = sum / divisor;
        System.out.println(mean);
}
}
