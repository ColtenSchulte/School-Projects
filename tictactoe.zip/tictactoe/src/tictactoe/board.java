/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

/**
 *
 * @author colts
 */
public class board {
    private static String tictactoeboard = "___|___|___\n___|___|___\n   |   | \n";
    private static int cellsinarow = 3;
    private static int sizeofcell = 4;
    private static int sizeOfRow = cellsinarow * sizeofcell;
    private static char[][]value = new char [cellsinarow][sizeofcell];
    private static char location;
    private static char X = 'X';
    private static char O = 'O';
    public static void TheBoard(){
        for(int i = 0; i<value.length; ++i){
            for(int n = 0; n<value[i].length; ++n){
                value[i][n] = ' ' ;
            }
        }
    }
    public static boolean marker(int marker, int row, int col){
        if(row >= 0 && col >= 0 && row <= 2 && col <= 2){
            if(checkmark(row, col)){
                if(marker == 1){
                    location = X;
                }else if (marker == 4){
                    location = O;
                }
                
          tictactoeboard = tictactoeboard.substring(0, sizeOfRow * row) + tictactoeboard.substring(sizeOfRow * row, (row * sizeOfRow) + (col * sizeofcell) + 1) + location + tictactoeboard.substring((row * sizeOfRow) + (col * sizeofcell) + 2);
          value[row][col] = location;
          return true;
          
    }else{
            return false;
        }
    
    }else{
                return false;
                }
    }
    public static boolean checkmark(int row, int col){
        return value[row][col]== 0;
    }
    public static String getBoard(){
        return tictactoeboard;
    }

}
