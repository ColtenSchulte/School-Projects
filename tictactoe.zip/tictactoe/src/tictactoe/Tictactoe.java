/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.util.Random;

/**
 *
 * @author colts
 */
public class Tictactoe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    board one = new board();
    Random R = new Random();
    one.TheBoard();
    int column = 4;
    Random col = new Random();
    int rowCh = 4;
    Random row = new Random();
    int max = 9;
    int count = 0;
    int X = 1;
    int O = 4;
    int mark = 1;
    int [][]Check = new int [3][3];
    while(true){
        int RandomR = row.nextInt(rowCh);
        int RandomCol = col.nextInt(column);
        if(one.marker(mark, RandomR, RandomCol)){
            Check[RandomR][RandomCol] = mark;
            System.out.println(one.getBoard());
            if(mark == X){
                mark = O;
            }else{
                mark = X;
            }
        }
        for (int i = 0; i < Check.length; ++i){
            for (int x = 0; x < Check[i].length; ++x){
                if(Check[i][x] == 1 || Check[i][x] == 4){
                    ++count;
                }
            }
        }
        if(count == max){
            break;
        }else{
            count = 0;
        }
    }
    
    }
    
}
