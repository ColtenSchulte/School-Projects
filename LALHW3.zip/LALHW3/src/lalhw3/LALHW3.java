/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lalhw3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author colts
 */
public class LALHW3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        List<Double> L = new ArrayList<>();
        Random R = new Random();
        double min = -500.0;
        double max = 500.0;
        int size = 10;
        int smallest = 0;
        for(int i = 0; i<size; ++i){
            L.add(R.nextDouble() * (max - min + 1) + min);
        }
        for (int i = 0; i<L.size(); ++i){
        if(L.get(smallest)>L.get(i)){
            smallest = i;
        }
    }
        System.out.println(L.get(smallest));
        System.out.println(L);
    }
    
}
