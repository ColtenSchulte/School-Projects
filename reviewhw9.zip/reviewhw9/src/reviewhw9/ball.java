/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reviewhw9;

import java.util.Random;

/**
 *
 * @author colts
 */
public class ball {
     private int maxHeight = 20;
    private int minHeight = 3;
    private int currentHeight = 0;
    private Random R = new Random();
    public void bounce(){
        currentHeight = R.nextInt(maxHeight + minHeight +1) + minHeight;
        
    }
    public int getHeight(){
        return currentHeight;
    }

}
