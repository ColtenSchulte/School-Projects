/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reviewhw9;

/**
 *
 * @author colts
 */
public class Reviewhw9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ball ballOne = new ball();
        ball ballTwo = new ball();
        int sum1 = 0;
        int sum2 = 0;
        ballOne.bounce();
        ballTwo.bounce();
        sum1 += ballOne.getHeight();
        sum2 += ballTwo.getHeight();
        int max = 300;
        int count = 1;
        while (sum1 < max || sum2 < max){
            ballOne.bounce();
            ballTwo.bounce();
            sum1 += ballOne.getHeight();
            sum2 += ballTwo.getHeight();
            ++count;
        }
        if(sum1 > sum2){
            System.out.println(sum1 + " For ball one, boumced " + count);
        }else{
            System.out.println(sum2 + " For ball two, bounced " + count);
        }
    }
    
}
