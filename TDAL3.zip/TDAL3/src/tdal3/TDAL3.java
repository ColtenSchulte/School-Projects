/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tdal3;

import java.util.Random;

/**
 *
 * @author colts
 */
public class TDAL3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Random R = new Random();
    int UB = 999;
    int LB = 1;
    int[][]A = new int [17][13];
    for(int row = 0; row<A.length; ++row){   
    for(int col = 0; col<A[row].length; ++col){
        A[row][col] = R.nextInt(UB-LB+1)+LB;
    }
    
}
    int[]value = findValue(A, 69);
    if(value[0] == -1 && value[1] == -1){
        System.out.println(value[0] + " " + value[1]);
    }else{
        System.out.println(value[0] + " " + value[1] + " " + A[value[0]][value[1]]);
}
    }
public static int[] findValue(int[][]A, int value){
        int[] notfound = {-1, -1};
        int[] found = {0, 0};
        for(int row = 0; row<A.length; ++row){   
    for(int col = 0; col<A[row].length; ++col){
        if(A[row][col] == value){
        found[0] = row;
        found[1] = col;
        return found;
    }
        
}
        }
        return notfound;
    }
}
