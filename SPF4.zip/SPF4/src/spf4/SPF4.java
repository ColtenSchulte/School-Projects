/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spf4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author colts
 */
public class SPF4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        int [] A = new int [30];
        int UB = 50;
        int LB = -50;
        Random R = new Random();
        for(int i = 0; i<A.length; ++i){
            A[i]=R.nextInt(UB-LB+1)+LB;
        }
        String fileName = "numbers.txt";
         int sum = 0;
        FileOutputStream fileOut = new FileOutputStream(fileName);
         FileInputStream fileIn = new FileInputStream(fileName);
         PrintWriter filePrinter = new PrintWriter(fileOut);
         Scanner fileReader = new Scanner(fileIn);
         for(int i = 0; i<A.length; ++i){
             filePrinter.println(A[i]);
              filePrinter.flush();
    }
    for(int i = 0; i<A.length; ++i){
        sum+=A[i];
         System.out.println(fileReader.nextLine());
    }
        System.out.println(sum);  
    }
            
             
}
